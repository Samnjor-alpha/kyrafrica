<?php if (!isset($_SESSION)){
    session_start();
}?>
<link rel="stylesheet" type="text/css" href="assets/styles.css">
<script src="assets/jquery.min.js"></script>
<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css"
rel="stylesheet" crossorigin="anonymous" />
<link type="text/css" rel="stylesheet" href="assets/jquery-te-1.4.0.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
<script src="assets/prokit.js"></script>
<link rel="stylesheet" type="text/css" href="assets/shimmer.css">
<link rel="stylesheet" type="text/css" href="assets/select2.min.css">
<script type="text/javascript" src="assets/jquery-te-1.4.0.min.js" charset="utf-8"></script>
<script type="text/javascript" src="assets/paging.js" charset="utf-8"></script>
<script type="text/javascript" src="assets/select2.min.js"></script>